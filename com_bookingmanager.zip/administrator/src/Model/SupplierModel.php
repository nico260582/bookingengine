<?php
namespace RTHolidays\Component\BookingManager\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Date\Date;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Form\Form;

class SupplierModel extends AdminModel
{
    public function getTable($type = 'Supplier', $prefix = 'BookingmanagerTable', $config = array())
    {
        return Table::getInstance($type, $prefix, $config);
    }

    public function getForm($data = array(), $loadData = true)
    {
        $this->addFormPath(JPATH_COMPONENT_ADMINISTRATOR . '/src/Form');
        $this->addFieldPath(JPATH_COMPONENT_ADMINISTRATOR . '/src/Field');
        $form = $this->loadForm('com_bookingmanager.supplier', 'supplier', ['control' => 'jform', 'load_data' => $loadData]);
        return empty($form) ? false : $form;
    }

    protected function loadFormData()
    {
        $data = Factory::getApplication()->getUserState('com_bookingmanager.edit.supplier.data', array());

        if (empty($data)) {
            $data = $this->getItem();

            if ($data) {
                if (!empty($data->rules)) {
                    $rules = json_decode($data->rules);
                    if (is_object($rules)) {
                        foreach ($rules as $key => $value) {
                            if (!isset($data->$key)) {
                                $data->$key = $value;
                            }
                        }
                    }
                }

                if (!empty($data->id)) {
                    $db = Factory::getDbo();
                    $query = $db->getQuery(true)->select('property_id')->from('#__bookingmanager_property_map')->where('supplier_id = ' . (int)$data->id);
                    $propertyIds = $db->setQuery($query)->loadColumn();
                    $data->properties = implode(',', $propertyIds);

                    // Load markets with their currencies and state
                    $query->clear()->select('market_name, currency, state')->from('#__bookingmanager_supplier_markets')->where('supplier_id = ' . (int)$data->id);
                    $data->markets = $db->setQuery($query)->loadAssocList();
                }
            }
        }

        if (is_object($data)) {
            $data = get_object_vars($data);
        }

        return $data;
    }

    public function save($data)
    {
        $table = $this->getTable();
        $pkValue = $data['id'] ?? 0;
        $oldData = null;
        if ($pkValue && $table->load($pkValue)) {
            $oldData = $table->getProperties();
        }

        $propertyIdsString = $data['properties'] ?? '';
        $assignedProperties = $propertyIdsString ? explode(',', $propertyIdsString) : [];
        $markets = $data['markets'] ?? [];

        // Unset these from the main data array so parent::save() doesn't see them
        unset($data['properties']);
        unset($data['markets']);

        $this->prepareRules($data);

        if (parent::save($data)) {
            $id = (int) $this->getState($this->getName() . '.id');

            // Get old assignments before updating
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->select('property_id')
                ->from($db->quoteName('#__bookingmanager_property_map'))
                ->where($db->quoteName('supplier_id') . ' = ' . $id);
            $oldAssignedProperties = $db->setQuery($query)->loadColumn();


            if ($oldData) {
                $table->load($id);
                $newData = $table->getProperties();
                $this->logChanges($id, $oldData, $newData);
            }

            $this->updatePropertyAssignments($id, $assignedProperties, $oldAssignedProperties);
            $this->updateMarkets($id, $markets);

            return true;
        }
        return false;
    }

    private function updateMarkets(int $supplierId, array $marketsData)
    {
        $db = Factory::getDbo();

        // Delete existing markets for this supplier
        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__bookingmanager_supplier_markets'))
            ->where($db->quoteName('supplier_id') . ' = ' . $supplierId);
        $db->setQuery($query)->execute();

        // Collect values to insert
        $values = [];
        if (!empty($marketsData)) {
            foreach ($marketsData as $market) {
                if (!empty($market['market_name']) && !empty($market['currency'])) {
                    $state = isset($market['state']) ? (int)$market['state'] : 0;
                    $symbol = $market['currency_symbol'] ?? '';
                    $values[] = $supplierId . ',' . $db->quote($market['market_name']) . ',' . $db->quote($market['currency']) . ',' . $db->quote($symbol) . ',' . $state;
                }
            }
        }

        // Insert new markets if any were provided
        if (!empty($values)) {
            $insertQuery = $db->getQuery(true)
                ->insert($db->quoteName('#__bookingmanager_supplier_markets'))
                ->columns([$db->quoteName('supplier_id'), $db->quoteName('market_name'), $db->quoteName('currency'), $db->quoteName('currency_symbol'), $db->quoteName('state')]);

            foreach($values as $value) {
                $insertQuery->values($value);
            }

            $db->setQuery($insertQuery)->execute();
        }
    }

    public function getChangeLog($supplierId)
    {
        if (!$supplierId) { return []; }
        $db = Factory::getDbo();
        $query = $db->getQuery(true)->select('*')->from('#__booking_supplier_logs')->where('supplier_id = ' . (int)$supplierId)->order('created_at DESC');
        return $db->setQuery($query)->loadObjectList();
    }

    private function prepareRules(array &$data)
    {
        $rules = new \stdClass();
        $rule_fields = ['pricing_model', 'adult_supplement', 'child_supplement', 'extra_mattress_fee', 'seasons', 'infant_max_age', 'child_max_age', 'teen_max_age', 'free_with_parents_age', 'country_discounts', 'coupon_codes'];
        foreach ($rule_fields as $field) {
            if (isset($data[$field])) {
                $rules->$field = $data[$field];
                unset($data[$field]);
            }
        }
        $data['rules'] = json_encode($rules);
    }

    private function updatePropertyAssignments(int $supplierId, array $newlyAssigned, array $previouslyAssigned)
    {
        $db = Factory::getDbo();
        $newlyAssigned = array_map('intval', $newlyAssigned);
        $previouslyAssigned = array_map('intval', $previouslyAssigned);

        $toAdd = array_diff($newlyAssigned, $previouslyAssigned);
        $toRemove = array_diff($previouslyAssigned, $newlyAssigned);

        // Add new properties to the #__bookingmanager_properties table
        if (!empty($toAdd)) {
            $addQuery = $db->getQuery(true)
                ->insert($db->quoteName('#__bookingmanager_properties'))
                ->columns([$db->quoteName('article_id'), $db->quoteName('max_guests'), $db->quoteName('number_of_units')]);
            foreach ($toAdd as $addId) {
                $addQuery->values((int)$addId . ', 2, 1'); // Default max_guests to 2, number_of_units to 1
            }
            $db->setQuery($addQuery)->execute();
        }

        // Remove unassigned properties from the #__bookingmanager_properties table
        if (!empty($toRemove)) {
            $removeQuery = $db->getQuery(true)
                ->delete($db->quoteName('#__bookingmanager_properties'))
                ->where($db->quoteName('article_id') . ' IN (' . implode(',', $toRemove) . ')');
            $db->setQuery($removeQuery)->execute();
        }

        // Now, update the mapping table
        $mapQuery = $db->getQuery(true)
            ->delete($db->quoteName('#__bookingmanager_property_map'))
            ->where($db->quoteName('supplier_id') . ' = ' . $supplierId);
        $db->setQuery($mapQuery)->execute();

        if (!empty($newlyAssigned)) {
            $insertMapQuery = $db->getQuery(true)
                ->insert($db->quoteName('#__bookingmanager_property_map'))
                ->columns([$db->quoteName('property_id'), $db->quoteName('supplier_id')]);

            foreach ($newlyAssigned as $propId) {
                $insertMapQuery->values((int)$propId . ',' . $supplierId);
            }
            $db->setQuery($insertMapQuery)->execute();
        }
    }

    public function getAllPropertiesWithAssignments($currentSupplierId = 0)
    {
        $db = Factory::getDbo();
        $user = Factory::getUser();
        $now  = (new Date('now'))->toSql();
        $nullDate = $db->getNullDate();
        $params = ComponentHelper::getParams('com_bookingmanager');
        $selectedCategories = $params->get('property_categories', []);
        $allCategoryIds = [];

        if (!empty($selectedCategories) && is_array($selectedCategories)) {
            $categoryIds = array_map('intval', $selectedCategories);
            $rangesQuery = $db->getQuery(true)
                ->select('c.lft, c.rgt')
                ->from($db->quoteName('#__categories', 'c'))
                ->where('c.id IN (' . implode(',', $categoryIds) . ')');
            $ranges = $db->setQuery($rangesQuery)->loadObjectList();

            if ($ranges) {
                $whereClauses = [];
                foreach ($ranges as $range) {
                    $whereClauses[] = '(c.lft >= ' . $range->lft . ' AND c.rgt <= ' . $range->rgt . ')';
                }
                $subCategoriesQuery = $db->getQuery(true)
                    ->select('c.id')
                    ->from($db->quoteName('#__categories', 'c'))
                    ->where('(' . implode(' OR ', $whereClauses) . ')')
                    ->where("c.extension = 'com_content'");
                $allCategoryIds = $db->setQuery($subCategoriesQuery)->loadColumn();
            }
        }

        $query = $db->getQuery(true)
            ->select('a.id, a.title')
            ->from($db->quoteName('#__content', 'a'))
            ->where('a.state = 1')
            ->where('a.catid > 0')
            ->where('a.access IN (' . implode(',', $user->getAuthorisedViewLevels()) . ')')
            ->where("a.publish_up <= " . $db->quote($now))
            ->where("(a.publish_down IS NULL OR a.publish_down = " . $db->quote($nullDate) . " OR a.publish_down >= " . $db->quote($now) . ")");

        if (!empty($allCategoryIds)) {
            $query->where('a.catid IN (' . implode(',', $allCategoryIds) . ')');
        }

        $query->order('a.title');
        $allProperties = $db->setQuery($query)->loadObjectList('id');

        $query->clear()
            ->select('m.property_id, m.supplier_id, s.abbreviation')
            ->from($db->quoteName('#__bookingmanager_property_map', 'm'))
            ->join('LEFT', $db->quoteName('#__bookingmanager_suppliers', 's') . ' ON m.supplier_id = s.id');
        $assignments = $db->setQuery($query)->loadObjectList('property_id');

        foreach ($allProperties as $id => &$property) {
            $property->assignment = null;
            if (isset($assignments[$id])) {
                $property->assignment = [
                    'supplier_id' => $assignments[$id]->supplier_id,
                    'abbreviation' => $assignments[$id]->abbreviation,
                    'is_current' => ($assignments[$id]->supplier_id == $currentSupplierId)
                ];
            }
        }
        return $allProperties;
    }

    private function logChanges($supplierId, $oldData, $newData)
    {
        $user = Factory::getUser();
        foreach ($newData as $key => $newValue) {
            if (!array_key_exists($key, $oldData) || $oldData[$key] == $newValue) {
                continue;
            }
            $oldValue = $oldData[$key];
            if ($key === 'rules') {
                $oldRules = json_decode($oldValue, true);
                $newRules = json_decode($newValue, true);
                foreach ($newRules as $ruleKey => $ruleValue) {
                    $oldRuleValue = $oldRules[$ruleKey] ?? null;
                    if (json_encode($oldRuleValue) !== json_encode($ruleValue)) {
                        $logValue = is_array($ruleValue) ? Text::_('COM_BOOKINGMANAGER_LOG_COMPLEX_DATA_CHANGED') : (string)$ruleValue;
                        $this->createLogEntry($supplierId, $user, "rules." . $ruleKey, is_array($oldRuleValue) ? Text::_('COM_BOOKINGMANAGER_LOG_COMPLEX_DATA_CHANGED') : (string)$oldRuleValue, $logValue);
                    }
                }
            } else {
                $this->createLogEntry($supplierId, $user, $key, (string)$oldValue, (string)$newValue);
            }
        }
    }

    private function createLogEntry($supplierId, $user, $fieldName, $oldValue, $newValue)
    {
        $log = new \stdClass();
        $log->supplier_id = $supplierId;
        $log->created_at  = (new Date('now'))->toSql();
        $log->user_id     = $user->id;
        $log->user_name   = $user->name;
        $log->field_name  = $fieldName;
        $log->old_value   = substr((string)$oldValue, 0, 1024);
        $log->new_value   = substr((string)$newValue, 0, 1024);
        $this->getDbo()->insertObject('#__booking_supplier_logs', $log);
    }
}