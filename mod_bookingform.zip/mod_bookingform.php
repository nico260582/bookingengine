<?php
use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Log\Log;
use RTHolidays\Module\BookingForm\Site\Helper\BookingFormHelper;
use RTHolidays\Component\BookingManager\Administrator\Helper\BookingmanagerHelper as AdminBookingmanagerHelper;


defined('_JEXEC') or die;

$app = Factory::getApplication();
$doc = $app->getDocument();

$articleId = $app->input->getCmd('view') === 'article' ? $app->input->getInt('id') : 0;
$view = $app->input->getCmd('view');
$option = $app->input->getCmd('option');

$articleTitle = '';
$pricingRules = null;
$totalAccommodationGuests = 0;
$countries = [];

// Load portal CSS if we are on the component's communication view
if ($option === 'com_bookingmanager' && $view === 'communication') {
    $portalCssPath = JPATH_SITE . '/modules/mod_bookingform/media/css/portal.css';
    if (file_exists($portalCssPath)) {
        // This adds the file's last modified time to the URL, forcing browsers to reload it when it changes.
        $doc->addStyleSheet(Uri::root(true) . '/modules/mod_bookingform/media/css/portal.css?v=' . filemtime($portalCssPath));
    }
}


if ($articleId && $view === 'article') {
    $db = Factory::getDbo();
    $query = $db->getQuery(true)
        ->select($db->quoteName(['title', 'catid']))
        ->from($db->quoteName('#__content'))
        ->where($db->quoteName('id') . ' = ' . (int)$articleId);
    $article = $db->setQuery($query)->loadObject();
    
    if ($article && $article->catid > 0) {
        $articleTitle = $article->title;
        $pricingRules = BookingFormHelper::getPricingDataForArticle($articleId);

        $propQuery = $db->getQuery(true)
            ->select('max_guests')
            ->from($db->quoteName('#__bookingmanager_properties'))
            ->where('article_id = ' . (int)$articleId);
        $totalAccommodationGuests = (int)$db->setQuery($propQuery)->loadResult();
    }
}

// Only render the booking form if we have pricing rules for it
if ($pricingRules) {
    if (ComponentHelper::isEnabled('com_bookingmanager'))
    {
        if (class_exists(AdminBookingmanagerHelper::class)) {
            $countries = AdminBookingmanagerHelper::getCountries();
        }
    }

    if (empty($countries)) {
        Log::add('Could not load countries from com_bookingmanager. Module will not render correctly.', Log::ERROR, 'mod_bookingform');
        return;
    }

    $cssPath = JPATH_SITE . '/modules/mod_bookingform/media/css/booking-form.css';
    if (file_exists($cssPath)) {
        $doc->addStyleSheet(Uri::root(true) . '/modules/mod_bookingform/media/css/booking-form.css?v=' . filemtime($cssPath));
    }

    $inlineCss = "
        /* Title style */
        .booking-form-header h5 {
          font-size: 1.2rem;
          color: #f37321;
          text-align: center;
          margin-bottom: 1rem;
          font-weight: bold;
        }
        /* Style for BOTH \"From\" price and \"Est.\" price */
        .price-total {
            font-size: 1.4rem;
            font-weight: bold;
            color: #f37321;
        }
        /* Style for the price summary box */
        #price-summary-container {
          text-align: center;
          margin: 10px 0;
          padding: 10px;
          background-color: #f8f8f8;
          border-radius: 5px;
        }
        /* Style for the suggestions box */
        #property-suggestion-alert.alert-info {
          color: #055160;
          background-color: #fff;
          border: 1px solid #ddd;
        }
        /* WhatsApp Icon styling */
        .whatsapp-icon {
            width: 20px;
            height: 20px;
            vertical-align: middle;
            filter: invert(48%) sepia(79%) saturate(2476%) hue-rotate(86deg) brightness(118%) contrast(119%);
        }
    ";
    $doc->addStyleDeclaration($inlineCss);
    $doc->addStyleSheet('https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/css/intlTelInput.css');
    $doc->addScript('https://cdn.jsdelivr.net/npm/litepicker/dist/litepicker.js');
    $doc->addScript('https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/js/intlTelInput.min.js');
    $jsPath = JPATH_SITE . '/modules/mod_bookingform/media/js/booking-form.js';
    $doc->addScript(Uri::root(true) . '/modules/mod_bookingform/media/js/booking-form.js?v=' . filemtime($jsPath), ['defer' => 'true']);

    $scriptOptions = [
        'rootUrl'        => Uri::root(),
        'totalAccommodationGuests' => $totalAccommodationGuests,
        'pricingRules'   => $pricingRules,
        'submissionUrl'  => Route::_('index.php?option=com_bookingmanager&task=submitBooking&format=json', false)
    ];
    $doc->addScriptOptions('mod_bookingform', $scriptOptions);

    require ModuleHelper::getLayoutPath('mod_bookingform', $params->get('layout', 'default'));
}